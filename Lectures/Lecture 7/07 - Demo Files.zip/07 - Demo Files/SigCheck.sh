#!/bin/bash

Files="/home/sansforensics/Documents/Lecture07/Files/*"
for f in $Files

do
  echo "$f"
  hexdump -C $f | head -n 3
  echo " "
  file "$f"
  echo " "
done
